package net.stark.nightvision;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class NightVision extends JavaPlugin implements Listener {

    private static final int GUI_SIZE = 45;
    private static final int CLOCK_SLOT = 22;

    /** Night vision is ON by default; only players who switched it OFF are stored. */
    private final Set<UUID> disabled = new HashSet<>();
    private File dataFile;

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onEnable() {
        dataFile = new File(getDataFolder(), "data.yml");
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);
        // Re-apply for players already online (e.g. after /reload)
        for (Player p : Bukkit.getOnlinePlayers()) {
            applyIfEnabled(p);
        }
    }

    @Override
    public void onDisable() {
        saveData();
    }

    // ---------------------------------------------------------------- command

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        openMenu(player);
        return true;
    }

    // ---------------------------------------------------------------- GUI

    private static final class NVHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public @NotNull Inventory getInventory() {
            return inventory;
        }
    }

    private void openMenu(Player player) {
        NVHolder holder = new NVHolder();
        Inventory inv = Bukkit.createInventory(holder, GUI_SIZE,
                Component.text("Night Vision", NamedTextColor.DARK_GRAY));
        holder.inventory = inv;

        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        glassMeta.displayName(Component.text(" "));
        glass.setItemMeta(glassMeta);
        for (int i = 0; i < GUI_SIZE; i++) {
            inv.setItem(i, glass);
        }

        inv.setItem(CLOCK_SLOT, buildClock(isEnabled(player.getUniqueId())));
        player.openInventory(inv);
    }

    private ItemStack buildClock(boolean on) {
        ItemStack clock = new ItemStack(Material.CLOCK);
        ItemMeta meta = clock.getItemMeta();
        meta.displayName(Component.text("Night Vision", NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("Status: ", NamedTextColor.GRAY)
                        .decoration(TextDecoration.ITALIC, false)
                        .append(on
                                ? Component.text("ON", NamedTextColor.GREEN, TextDecoration.BOLD)
                                : Component.text("OFF", NamedTextColor.RED, TextDecoration.BOLD))
                        .decoration(TextDecoration.ITALIC, false),
                Component.empty(),
                Component.text("Click to toggle", NamedTextColor.DARK_GRAY)
                        .decoration(TextDecoration.ITALIC, false)
        ));
        clock.setItemMeta(meta);
        return clock;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof NVHolder)) return;
        event.setCancelled(true); // nothing can be taken, moved or shift-clicked

        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null
                || !(event.getClickedInventory().getHolder() instanceof NVHolder)) return;
        if (event.getRawSlot() != CLOCK_SLOT) return;

        boolean nowOn = toggle(player);
        event.getInventory().setItem(CLOCK_SLOT, buildClock(nowOn));
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, nowOn ? 1.4f : 0.8f);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof NVHolder) {
            event.setCancelled(true);
        }
    }

    // ---------------------------------------------------------------- toggle / effect

    private boolean toggle(Player player) {
        UUID id = player.getUniqueId();
        if (isEnabled(id)) {
            disabled.add(id);
            player.removePotionEffect(PotionEffectType.NIGHT_VISION);
            saveData();
            return false;
        }
        disabled.remove(id);
        applyEffect(player);
        saveData();
        return true;
    }

    private boolean isEnabled(UUID id) {
        return !disabled.contains(id);
    }

    private void applyEffect(Player player) {
        // Infinite duration, no particles, no icon, ambient off
        player.addPotionEffect(new PotionEffect(
                PotionEffectType.NIGHT_VISION,
                PotionEffect.INFINITE_DURATION,
                0, false, false, false));
    }

    private void applyIfEnabled(Player player) {
        if (player.isOnline() && isEnabled(player.getUniqueId())) {
            applyEffect(player);
        }
    }

    private void applyNextTick(Player player) {
        // 1 tick later so we run after Minecraft clears/replaces effects
        Bukkit.getScheduler().runTask(this, () -> applyIfEnabled(player));
    }

    // ---------------------------------------------------------------- keep effect

    /** Totem of Undying pop clears all effects -> re-apply. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTotemPop(EntityResurrectEvent event) {
        if (event.getEntity() instanceof Player player) {
            applyNextTick(player);
        }
    }

    /** Death clears all effects -> re-apply on respawn. */
    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        applyNextTick(event.getPlayer());
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        applyNextTick(event.getPlayer());
    }

    /** Milk bucket clears all effects -> re-apply. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onConsume(PlayerItemConsumeEvent event) {
        if (event.getItem().getType() == Material.MILK_BUCKET) {
            applyNextTick(event.getPlayer());
        }
    }

    // ---------------------------------------------------------------- storage

    private void loadData() {
        disabled.clear();
        if (!dataFile.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(dataFile);
        for (String s : yml.getStringList("disabled")) {
            try {
                disabled.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveData() {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("disabled", disabled.stream().map(UUID::toString).toList());
        try {
            getDataFolder().mkdirs();
            yml.save(dataFile);
        } catch (IOException e) {
            getLogger().warning("Could not save data.yml: " + e.getMessage());
        }
    }
}
